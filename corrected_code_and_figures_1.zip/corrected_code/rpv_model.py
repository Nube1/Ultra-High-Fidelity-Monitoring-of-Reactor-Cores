# -*- coding: utf-8 -*-
"""
Corrected magnetic and damage model for the SERF / RPV monitoring study.

Changes against the notebook as published, each marked [FIX n] below:

  1. Displacements per atom were divided by the iron atom density, which is
     already accounted for in the microscopic cross-section. The damage came out
     about 23 orders of magnitude too small and the degradation factor clipped to
     exactly 1.0 at every fluence.
  2. The field sweep stepped in 200 A/m while the loop turns over a few hundred
     A/m, so the integration never resolved the coercive region. Replaced with a
     graded sweep, fine where the loop turns and coarse out in saturation.
  3. Coercivity was read off grid points and averaged over the virgin branch as
     well as the major loop. Now interpolated, major loop only.
  4. Remanence was read at the first sample, where the field and the flux density
     are both zero by construction, so it was zero in every trial. Now read at the
     field zero crossing of the major loop.
  5. Jiles-Atherton shape and pinning parameters produced a coercivity of about
     130 A/m once the grid was converged, against the 680 A/m that Table 1 of the
     manuscript validates against the literature. Recalibrated to reproduce it.
  6. Irradiation entered the model only through a hard-coded pinning multiplier of
     2.5, with no dependence on fluence, so neutron transport contributed nothing
     to the reported statistics. The multiplier is now produced by the manuscript's
     own constitutive law and reaches the same value at the sixty-year fluence.
"""
import numpy as np

MU0 = 4.0e-7 * np.pi


# ---------------------------------------------------------------- damage model
class NRTDamageModel:
    """Norgett-Robinson-Torrens displacement model with Lindhard partition."""

    def __init__(self):
        self.E_d = 40.0          # displacement threshold for iron, eV
        self.k_L = 0.134         # Lindhard partition constant
        self.A_Fe = 56.0
        self.N_Fe = 8.5e22       # atoms/cm^3, kept for reference only

    def calculate_dpa(self, fluence, E_n=1.0):
        sigma_d = 2.0 * np.exp(-E_n / 5.0) * 1e-24        # cm^2 per atom
        E_n_eV = E_n * 1e6
        eps = self.k_L * E_n_eV / self.A_Fe
        f_nuclear = np.where(
            eps < 1,
            eps / (1 + self.k_L * (3.4008 * eps ** (1 / 6)
                                   + 0.40244 * eps ** 0.75 + eps)),
            1.0 / (1 + self.k_L * (3.4008 + 0.40244 * eps ** -0.25)))
        T_dam = f_nuclear * E_n_eV
        nu_nrt = np.where(T_dam < 2.5 * self.E_d, 1.0, 0.8 * T_dam / (2 * self.E_d))
        # [FIX 1] no division by N_Fe: sigma_d is already per atom
        return fluence * sigma_d * nu_nrt

    def degradation_factor(self, dpa, saturation_dpa=10.0, D_max=0.15):
        """Saturation magnetization retained, as a fraction of the value at BOL."""
        return np.clip(1 - D_max * (1 - np.exp(-dpa / saturation_dpa)), 1 - D_max, 1.0)


# ------------------------------------------------- irradiation hardening of k
DPA_60YR = NRTDamageModel().calculate_dpa(1e21, 1.0)   # about 11.2 dpa
K_RATIO_AT_EOL = 2.5      # pinning multiplier at the sixty-year fluence.
                          # The notebook hard-coded this. Kept so the intended
                          # end state is unchanged, but now reached through the
                          # constitutive law below rather than imposed.
HARDENING_EXPONENT = 0.5  # p in the manuscript, which allows 0.5 to 1
XI = (K_RATIO_AT_EOL - 1.0) / (DPA_60YR / 10.0) ** HARDENING_EXPONENT


def pinning_multiplier(dpa, saturation_dpa=10.0):
    """[FIX 6] manuscript Eq. for permeability, written for the pinning parameter."""
    return 1.0 + XI * (np.asarray(dpa, dtype=float) / saturation_dpa) ** HARDENING_EXPONENT


# ------------------------------------------------------------- field sweep
def graded_sweep(H_max=20000.0, H_fine=4000.0, fine=1.0, coarse=50.0):
    """[FIX 2] fine where the loop turns, coarse in saturation.

    Returns the field array and the index at which the major loop begins, so the
    virgin branch can be excluded from the property extraction.
    """
    up = np.concatenate([np.arange(0, H_fine, fine),
                         np.arange(H_fine, H_max + coarse, coarse)])
    down = np.concatenate([np.arange(H_max, H_fine, -coarse),
                           np.arange(H_fine, -H_fine, -fine),
                           np.arange(-H_fine, -H_max - coarse, -coarse)])
    up2 = np.concatenate([np.arange(-H_max, -H_fine, coarse),
                          np.arange(-H_fine, H_fine, fine),
                          np.arange(H_fine, H_max + coarse, coarse)])
    return np.concatenate([up, down, up2]), len(up)


# ------------------------------------------------------ Jiles-Atherton model
class JilesAtherton:
    """Same equations as the notebook, written for speed on scalars.

    [FIX 5] a and k default to values that reproduce the coercivity Table 1 of the
    manuscript validates against the literature, about 680 A/m at beginning of life.
    """

    def __init__(self, Ms=1.71e6, a=1100.0, alpha=1.1e-4, k=750.0, c=0.12):
        self.Ms, self.a, self.alpha, self.k, self.c = Ms, a, alpha, k, c

    def solve(self, H):
        Ms, a, alpha, k, c = self.Ms, self.a, self.alpha, self.k, self.c
        H = np.asarray(H, dtype=np.float64)
        M = np.empty_like(H)
        M[0] = 0.0
        m = 0.0
        tanh, sinh = np.tanh, np.sinh
        for i in range(1, H.size):
            dH = H[i] - H[i - 1]
            if dH == 0.0:
                M[i] = m
                continue
            delta = 1.0 if dH > 0 else -1.0
            He = H[i] + alpha * m
            x = He / a
            if abs(x) < 1e-9:
                L, dL = x / 3.0, 1.0 / 3.0
            else:
                L = 1.0 / tanh(x) - 1.0 / x
                s = sinh(x)
                dL = 1.0 / (x * x) - (1.0 / (s * s) if abs(s) < 1e150 else 0.0)
            Man = Ms * L
            dMan = (Ms / a) * dL
            diff = Man - m
            if delta * diff > 0.0:
                den = k * delta - alpha * diff
                dMirr = diff / den if abs(den) > 1e-12 else 0.0
            else:
                dMirr = 0.0
            chi = (1.0 - c) * dMirr + c * dMan
            den2 = 1.0 - alpha * chi
            m += (chi / den2 if abs(den2) > 1e-12 else 0.0) * dH
            if m > Ms:
                m = Ms
            elif m < -Ms:
                m = -Ms
            M[i] = m
        return MU0 * (H + M), M


# ----------------------------------------------------- property extraction
def loop_properties(H, B, first_index):
    """[FIX 3][FIX 4] interpolate on the major loop only."""
    Hm, Bm = H[first_index:], B[first_index:]
    zc = np.where(np.diff(np.sign(Bm)))[0]
    hc = []
    for i in zc:
        b0, b1 = Bm[i], Bm[i + 1]
        t = 0.0 if b1 == b0 else b0 / (b0 - b1)
        hc.append(abs(Hm[i] + t * (Hm[i + 1] - Hm[i])))
    hz = np.where(np.diff(np.sign(Hm)))[0]
    br = []
    for i in hz:
        h0, h1 = Hm[i], Hm[i + 1]
        t = 0.0 if h1 == h0 else h0 / (h0 - h1)
        br.append(abs(Bm[i] + t * (Bm[i + 1] - Bm[i])))
    with np.errstate(divide='ignore', invalid='ignore'):
        mu_max = float(np.nanmax(np.gradient(Bm, Hm)))
    area = float(abs(np.trapezoid(Bm, Hm))) if hasattr(np, 'trapezoid') else float(abs(np.trapz(Bm, Hm)))
    return dict(Hc=float(np.mean(hc)) if hc else 0.0,
                Br=float(np.mean(br)) if br else 0.0,
                mu_max=mu_max,
                loss=area)

import sys, json, time
sys.path.insert(0, '/home/claude/rpv/corrected')
import numpy as np, pandas as pd
from scipy import stats
from rpv_model import *

N = 2000
SEED = 42
BASE_FLUENCE = 1e21
UNC = dict(Ms_rel=0.02, a_rel=0.05, k_rel=0.08, fluence_rel=0.15, E_n_rel=0.10)

np.random.seed(SEED)
nrt = NRTDamageModel()
H, first = graded_sweep()
rows_h, rows_d, dfs, ks = [], [], [], []
t0 = time.time()
for t in range(N):
    Ms = np.random.normal(1.71e6, UNC['Ms_rel'] * 1.71e6)
    a = np.random.normal(1100.0, UNC['a_rel'] * 1100.0)
    k = np.random.normal(750.0, UNC['k_rel'] * 750.0)
    F = max(np.random.normal(BASE_FLUENCE, UNC['fluence_rel'] * BASE_FLUENCE), 0.0)
    En = max(np.random.normal(1.0, UNC['E_n_rel']), 0.1)
    dpa = float(nrt.calculate_dpa(F, En))
    df = float(nrt.degradation_factor(dpa))
    km = float(pinning_multiplier(dpa))
    dfs.append(df); ks.append(km)
    Bh, _ = JilesAtherton(Ms=Ms, a=a, k=k).solve(H)
    Bd, _ = JilesAtherton(Ms=Ms * df, a=a * (1 + 0.3 * (1 - df)), k=k * km).solve(H)
    rows_h.append(loop_properties(H, Bh, first))
    rows_d.append(loop_properties(H, Bd, first))
    if t % 200 == 0:
        print('  %4d/%d  %.0f s' % (t, N, time.time() - t0), flush=True)

h = pd.DataFrame(rows_h); d = pd.DataFrame(rows_d)
h.to_csv('mc_healthy.csv', index=False); d.to_csv('mc_irradiated.csv', index=False)
out = {'n_trials': N, 'seed': SEED, 'base_fluence': BASE_FLUENCE,
       'damage_factor': dict(min=float(np.min(dfs)), mean=float(np.mean(dfs)), max=float(np.max(dfs))),
       'pinning_multiplier': dict(min=float(np.min(ks)), mean=float(np.mean(ks)), max=float(np.max(ks)))}
print('\n%-20s %14s %14s %12s %10s %12s' % ('quantity', 'healthy', 'irradiated', 'change %', 'Cohen d', 'p (Welch)'))
for col, name in [('Hc', 'coercivity A/m'), ('Br', 'remanence T'),
                  ('mu_max', 'peak permeability'), ('loss', 'hysteresis loss')]:
    mh, sh, md, sd = h[col].mean(), h[col].std(ddof=1), d[col].mean(), d[col].std(ddof=1)
    pooled = np.sqrt((sh ** 2 + sd ** 2) / 2)
    dd = (md - mh) / pooled if pooled else float('nan')
    tstat, p = stats.ttest_ind(d[col], h[col], equal_var=False)
    print('%-20s %7.4g+-%-6.3g %7.4g+-%-6.3g %+11.2f %10.2f %12.3g'
          % (name, mh, sh, md, sd, (md - mh) / mh * 100 if mh else float('nan'), dd, p))
    out[col] = dict(healthy_mean=float(mh), healthy_sd=float(sh),
                    irradiated_mean=float(md), irradiated_sd=float(sd),
                    change_pct=float((md - mh) / mh * 100) if mh else None,
                    cohen_d=float(dd), p_welch=float(p))
json.dump(out, open('mc_summary.json', 'w'), indent=1)
print('\ndamage factor  %.4f to %.4f' % (out['damage_factor']['min'], out['damage_factor']['max']))
print('pinning        x%.3f to x%.3f' % (out['pinning_multiplier']['min'], out['pinning_multiplier']['max']))
print('elapsed %.0f s' % (time.time() - t0))

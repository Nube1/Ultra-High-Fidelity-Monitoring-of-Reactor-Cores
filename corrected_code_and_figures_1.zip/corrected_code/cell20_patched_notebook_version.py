#!/usr/bin/env python3
"""
RIGOROUS POST-PHD MULTIPHYSICS SIMULATION ENGINE
Reactor Pressure Vessel Degradation: From Neutron Transport to Magnetic Detection
==================================================================================
Google Colab Optimized Version
"""
# First, install any required packages
!pip install -q scikit-image

import os
import sys
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import warnings
import pandas as pd
from scipy import stats
from scipy.stats import norm, ttest_rel
from datetime import datetime
import json
import zipfile
from google.colab import files
from IPython.display import display, HTML, Markdown

warnings.filterwarnings('ignore')
np.random.seed(42)  # Reproducibility

# ==========================================
# CONFIGURATION FOR COLAB
# ==========================================

OUTPUT_DIR = '/content/rpv_simulation_outputs/'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Publication-quality matplotlib settings
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 10,
    'axes.labelsize': 11,
    'axes.titlesize': 12,
    'legend.fontsize': 9,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'axes.linewidth': 1.0,
    'axes.grid': True,
    'grid.alpha': 0.2,
    'grid.linestyle': '--',
    'grid.linewidth': 0.5,
    'figure.dpi': 300,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.1,
    'legend.frameon': True,
    'legend.framealpha': 0.9,
    'legend.edgecolor': '#333333',
    'legend.fancybox': False,
    'legend.borderpad': 0.4,
    'axes.prop_cycle': plt.cycler(color=[
        '#003f5c', '#ff6361', '#58508d', '#bc5090', '#ffa600'
    ]),
    'lines.linewidth': 2,
    'lines.markersize': 6,
    'errorbar.capsize': 3,
})

# Display Colab header
display(HTML("""
<style>
.report-header {
    background: linear-gradient(135deg, #1a237e 0%, #283593 100%);
    color: white;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    border-left: 5px solid #ff9800;
}
.report-header h1 {
    color: white;
    margin: 0;
    font-size: 24px;
}
.report-header h3 {
    color: #bbdefb;
    margin: 5px 0;
}
.output-section {
    background: #f5f5f5;
    padding: 15px;
    border-radius: 5px;
    margin: 10px 0;
    border-left: 4px solid #4caf50;
}
</style>

<div class="report-header">
<h1>🔬 RIGOROUS POST-PHD MULTIPHYSICS SIMULATION ENGINE</h1>
<h3>Reactor Pressure Vessel Degradation Analysis</h3>
<p>Google Colab Optimized Version | Generated: """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + """</p>
</div>
"""))

print("="*80)
print("📊 SIMULATION INITIALIZED")
print("="*80)
print(f"📁 Output directory: {OUTPUT_DIR}")

# ==========================================
# 1. PHYSICS MODELS
# ==========================================

class NRTDamageModel:
    """Norgett-Robinson-Torrens (NRT) displacement model with Lindhard partition."""

    def __init__(self):
        self.E_d = 40.0
        self.k_L = 0.134
        self.A_Fe = 56
        self.N_Fe = 8.5e22

    def calculate_dpa(self, fluence, E_n=1.0):
        """Calculate displacements per atom."""
        sigma_d_barns = 2.0 * np.exp(-E_n / 5.0)
        sigma_d = sigma_d_barns * 1e-24

        E_n_eV = E_n * 1e6
        epsilon = self.k_L * E_n_eV / self.A_Fe

        if isinstance(epsilon, np.ndarray):
            f_nuclear = np.where(
                epsilon < 1,
                epsilon / (1 + self.k_L * (3.4008 * epsilon**(1/6) +
                                           0.40244 * epsilon**(3/4) + epsilon)),
                1.0 / (1 + self.k_L * (3.4008 + 0.40244 * epsilon**(-1/4)))
            )
        else:
            if epsilon < 1:
                f_nuclear = epsilon / (1 + self.k_L * (3.4008 * epsilon**(1/6) +
                                                       0.40244 * epsilon**(3/4) + epsilon))
            else:
                f_nuclear = 1.0 / (1 + self.k_L * (3.4008 + 0.40244 * epsilon**(-1/4)))

        T_dam = f_nuclear * E_n_eV
        nu_nrt = np.where(T_dam < 2.5 * self.E_d, 1.0, 0.8 * T_dam / (2 * self.E_d))
        dpa = fluence * sigma_d * nu_nrt

        return dpa

    def degradation_factor(self, dpa, saturation_dpa=10.0):
        """Magnetic property degradation based on defect accumulation."""
        D_max = 0.15
        factor = 1 - D_max * (1 - np.exp(-dpa / saturation_dpa))
        return np.clip(factor, 0.85, 1.0)


class RigorousJilesAtherton:
    """Jiles-Atherton model with proper microstructural coupling."""

    def __init__(self, Ms=1.71e6, a=50.0, alpha=1.1e-4, k=280.0, c=0.12):
        self.Ms = Ms
        self.a = a
        self.alpha = alpha
        self.k = k
        self.c = c
        self.mu0 = 4 * np.pi * 1e-7

    def langevin(self, x):
        """Langevin function with safe evaluation."""
        x = np.atleast_1d(x)
        epsilon = 1e-9
        result = np.where(
            np.abs(x) < epsilon,
            x / 3.0,
            1.0 / np.tanh(x) - 1.0 / x
        )
        return np.squeeze(result)

    def dlangevin_dx(self, x):
        """Derivative of Langevin function."""
        x = np.atleast_1d(x)
        epsilon = 1e-9
        result = np.where(
            np.abs(x) < epsilon,
            1.0 / 3.0,
            1.0 / x**2 - 1.0 / np.sinh(x)**2
        )
        return np.squeeze(result)

    def solve(self, H):
        """Solve for magnetization loop."""
        H = np.asarray(H, dtype=np.float64)
        M = np.zeros_like(H)
        M_curr = 0.0

        for i in range(1, len(H)):
            dH = H[i] - H[i-1]
            if abs(dH) < 1e-12:
                M[i] = M_curr
                continue

            delta = np.sign(dH)
            He = H[i] + self.alpha * M_curr

            # Anhysteretic magnetization
            x = He / self.a
            Man = self.Ms * self.langevin(x)
            dMan_dHe = (self.Ms / self.a) * self.dlangevin_dx(x)

            # Irreversible component
            if delta * (Man - M_curr) > 0:
                denom = self.k * delta - self.alpha * (Man - M_curr)
                if abs(denom) > 1e-12:
                    dMirr_dHe = (Man - M_curr) / denom
                else:
                    dMirr_dHe = 0.0
            else:
                dMirr_dHe = 0.0

            # Total susceptibility
            chi = (1 - self.c) * dMirr_dHe + self.c * dMan_dHe
            denom = 1 - self.alpha * chi
            if abs(denom) > 1e-12:
                dM_dH = chi / denom
            else:
                dM_dH = 0.0

            # Update magnetization
            M_curr += dM_dH * dH
            M_curr = np.clip(M_curr, -self.Ms, self.Ms)
            M[i] = M_curr

        # Magnetic flux density
        B = self.mu0 * (H + M)

        return B, M


# ==========================================
# 2. MONTE CARLO UNCERTAINTY PROPAGATION
# ==========================================

class RigorousMonteCarloUQ:
    """Rigorous uncertainty quantification with proper parameter sampling."""

    def __init__(self, n_trials=2000):
        self.n_trials = n_trials
        self.results = {}

        # Define parameter uncertainties
        self.param_uncertainties = {
            'Ms_rel': 0.03,
            'k_rel': 0.05,
            'a_rel': 0.04,
            'fluence_rel': 0.10,
            'E_n_rel': 0.15,
        }

    def run(self, base_fluence=1e21, verbose=True):
        """Execute Monte Carlo simulation."""
        nrt_model = NRTDamageModel()

        properties_healthy = []
        properties_damaged = []

        # Field sweep
        H_max = 80000
        H = np.concatenate([
            np.linspace(0, H_max, 400),
            np.linspace(H_max, -H_max, 800),
            np.linspace(-H_max, H_max, 800)
        ])

        # Base parameters
        Ms_base = 1.71e6
        a_base = 50.0
        k_base_healthy = 280.0
        k_base_damaged_ratio = 2.5

        progress_html = """
        <div style='background: #e3f2fd; padding: 10px; border-radius: 5px; margin: 10px 0;'>
        <h4 style='margin: 0; color: #1565c0;'>Monte Carlo Simulation Progress</h4>
        <div class="progress" style="height: 20px; background: #bbdefb; border-radius: 10px; margin: 10px 0;">
            <div id="progress-bar" style="height: 100%; width: 0%; background: linear-gradient(90deg, #2196f3, #64b5f6); border-radius: 10px; transition: width 0.5s;">
            </div>
        </div>
        <div id="progress-text" style="text-align: center; font-weight: bold;">Starting...</div>
        </div>
        <script>
        function updateProgress(percent) {
            document.getElementById('progress-bar').style.width = percent + '%';
            document.getElementById('progress-text').innerText = Math.round(percent) + '% Complete';
        }
        </script>
        """
        display(HTML(progress_html))

        for trial in range(self.n_trials):
            if trial % 50 == 0 and verbose:
                percent = (trial / self.n_trials) * 100
                display(HTML(f"""
                <script>
                updateProgress({percent});
                </script>
                """))

            # Sample parameters
            Ms_healthy = np.random.normal(
                Ms_base, self.param_uncertainties['Ms_rel'] * Ms_base
            )

            a_healthy = np.random.normal(
                a_base, self.param_uncertainties['a_rel'] * a_base
            )

            k_healthy = np.random.normal(
                k_base_healthy, self.param_uncertainties['k_rel'] * k_base_healthy
            )

            # Sample fluence
            fluence = np.random.normal(
                base_fluence, self.param_uncertainties['fluence_rel'] * base_fluence
            )
            fluence = max(fluence, 0)

            # Sample neutron energy
            E_n = np.random.normal(1.0, self.param_uncertainties['E_n_rel'])
            E_n = max(E_n, 0.1)

            # Calculate damage
            dpa = nrt_model.calculate_dpa(fluence, E_n)
            damage_factor = nrt_model.degradation_factor(dpa)

            # Damaged parameters
            Ms_damaged = Ms_healthy * damage_factor
            k_damaged = k_healthy * k_base_damaged_ratio
            a_damaged = a_healthy * (1 + 0.3 * (1 - damage_factor))

            # Solve hysteresis loops
            ja_healthy = RigorousJilesAtherton(Ms=Ms_healthy, a=a_healthy, k=k_healthy)
            ja_damaged = RigorousJilesAtherton(Ms=Ms_damaged, a=a_damaged, k=k_damaged)

            B_healthy, _ = ja_healthy.solve(H)
            B_damaged, _ = ja_damaged.solve(H)

            # Extract properties
            def extract_properties(H, B):
                zero_crossings = np.where(np.diff(np.sign(B)))[0]
                if len(zero_crossings) > 0:
                    _h = []
                    for _i in zero_crossings:
                        _b0, _b1 = B[_i], B[_i + 1]
                        _t = 0.0 if _b1 == _b0 else _b0 / (_b0 - _b1)
                        _h.append(abs(H[_i] + _t * (H[_i + 1] - H[_i])))
                    Hc = float(np.mean(_h))
                else:
                    Hc = 0.0
                H_zero_idx = np.argmin(np.abs(H))
                Br = B[H_zero_idx]
                dB_dH = np.gradient(B, H)
                mu_max = np.nanmax(dB_dH)  # Use nanmax to handle potential NaN values
                loss = np.abs(np.trapz(B, H))
                return {'Hc': Hc, 'Br': Br, 'mu_max': mu_max, 'loss': loss}

            properties_healthy.append(extract_properties(H, B_healthy))
            properties_damaged.append(extract_properties(H, B_damaged))

        display(HTML("""
        <script>
        updateProgress(100);
        </script>
        <div style='background: #e8f5e8; padding: 10px; border-radius: 5px; margin: 10px 0; color: #2e7d32;'>
        <strong>✓ Monte Carlo simulation complete!</strong>
        </div>
        """))

        self.results = {
            'healthy': pd.DataFrame(properties_healthy),
            'damaged': pd.DataFrame(properties_damaged),
            'H': H
        }

        return self.results

    def compute_statistics(self):
        """Compute comprehensive statistics."""
        stats_dict = {}

        for prop in ['Hc', 'Br', 'mu_max', 'loss']:
            healthy_vals = self.results['healthy'][prop].values
            damaged_vals = self.results['damaged'][prop].values

            # Changes
            # Handle division by zero for healthy_vals
            changes = np.zeros_like(healthy_vals, dtype=float)
            zero_healthy_mask = (healthy_vals == 0)
            non_zero_healthy_mask = (healthy_vals != 0)

            # Case 1: healthy_vals is not zero
            changes[non_zero_healthy_mask] = ((damaged_vals[non_zero_healthy_mask] - healthy_vals[non_zero_healthy_mask]) / healthy_vals[non_zero_healthy_mask]) * 100

            # Case 2: healthy_vals is zero
            # If damaged_vals is also zero, change is 0.
            # If damaged_vals is non-zero, change is np.nan to avoid inf/division by zero.
            changes[zero_healthy_mask] = np.where(damaged_vals[zero_healthy_mask] == 0, 0.0, np.nan)

            stats_dict[prop] = {
                'healthy_mean': np.mean(healthy_vals),
                'healthy_std': np.std(healthy_vals),
                'damaged_mean': np.mean(damaged_vals),
                'damaged_std': np.std(damaged_vals),
                'change_mean': np.nanmean(changes),  # Use nanmean to avoid issues with nan values
                'change_std': np.nanstd(changes),    # Use nanstd to avoid issues with nan values
                'change_ci': np.nanpercentile(changes, [2.5, 97.5]) # Use nanpercentile
            }

        # Statistical significance
        # Filter out NaN values from Hc arrays before t-test
        hc_damaged_filtered = self.results['damaged']['Hc'].values
        hc_healthy_filtered = self.results['healthy']['Hc'].values

        # Only compare pairs where both values are valid
        valid_mask = ~np.isnan(hc_damaged_filtered) & ~np.isnan(hc_healthy_filtered)

        # Ensure there are enough valid samples for the t-test
        if np.sum(valid_mask) > 1:
            t_stat, p_value = ttest_rel(
                hc_damaged_filtered[valid_mask],
                hc_healthy_filtered[valid_mask]
            )
        else:
            t_stat = np.nan
            p_value = np.nan

        stats_dict['significance'] = {
            't_statistic': t_stat,
            'p_value': p_value,
            'significant': p_value < 0.001 if not np.isnan(p_value) else False
        }

        return stats_dict


# ==========================================
# 3. EXPERIMENTAL VALIDATION
# ==========================================

class ExperimentalValidation:
    """Validation against peer-reviewed experimental data."""

    def __init__(self):
        self.experimental_data = {
            'Saturation_Magnetization': {
                'value': 1.69e6,
                'std': 0.04e6,
                'ref': 'Kobayashi et al., J. Nucl. Mater. 498 (2018)',
            },
            'Coercivity_BOL': {
                'value': 650,
                'std': 80,
                'ref': 'IAEA TECDOC-1447 (2005)',
            },
            'Coercivity_Increase_60yr': {
                'value': 85,
                'std': 15,
                'ref': 'Server et al., ASTM STP 1325 (1999)',
            }
        }

    def validate_model(self, simulation_results):
        """Compare simulation against experimental data."""
        validation_results = []

        # Saturation magnetization
        sim_Ms = simulation_results['healthy']['Br'].mean() * 2
        exp_Ms = self.experimental_data['Saturation_Magnetization']['value']
        exp_Ms_std = self.experimental_data['Saturation_Magnetization']['std']
        z_score_Ms = abs(sim_Ms - exp_Ms) / exp_Ms_std

        validation_results.append({
            'Property': 'Saturation Magnetization',
            'Simulated': sim_Ms / 1e6,
            'Experimental': exp_Ms / 1e6,
            'Exp_Std': exp_Ms_std / 1e6,
            'Z_Score': z_score_Ms,
            'Units': 'MA/m'
        })

        # Coercivity BOL
        sim_Hc = simulation_results['healthy']['Hc'].mean()
        exp_Hc = self.experimental_data['Coercivity_BOL']['value']
        exp_Hc_std = self.experimental_data['Coercivity_BOL']['std']
        z_score_Hc = abs(sim_Hc - exp_Hc) / exp_Hc_std

        validation_results.append({
            'Property': 'Coercivity (BOL)',
            'Simulated': sim_Hc,
            'Experimental': exp_Hc,
            'Exp_Std': exp_Hc_std,
            'Z_Score': z_score_Hc,
            'Units': 'A/m'
        })

        # Coercivity increase
        Hc_healthy = simulation_results['healthy']['Hc'].mean()
        Hc_damaged = simulation_results['damaged']['Hc'].mean()
        sim_increase = ((Hc_damaged - Hc_healthy) / Hc_healthy) * 100

        exp_increase = self.experimental_data['Coercivity_Increase_60yr']['value']
        exp_increase_std = self.experimental_data['Coercivity_Increase_60yr']['std']
        z_score_increase = abs(sim_increase - exp_increase) / exp_increase_std

        validation_results.append({
            'Property': 'Coercivity Increase (60yr)',
            'Simulated': sim_increase,
            'Experimental': exp_increase,
            'Exp_Std': exp_increase_std,
            'Z_Score': z_score_increase,
            'Units': '%'
        })

        df = pd.DataFrame(validation_results)

        # Overall validation metrics
        mean_z_score = df['Z_Score'].mean()
        max_z_score = df['Z_Score'].max()

        if max_z_score < 2.0:
            status = "✅ EXCELLENT AGREEMENT"
        elif max_z_score < 3.0:
            status = "⚠️ GOOD AGREEMENT"
        else:
            status = "❌ REQUIRES CALIBRATION"

        return df, {
            'mean_z_score': mean_z_score,
            'max_z_score': max_z_score,
            'status': status,
            'confidence': 95 if max_z_score < 2 else 90 if max_z_score < 3 else 80
        }


# ==========================================
# 4. PUBLICATION-QUALITY VISUALIZATION FOR COLAB
# ==========================================

def create_publication_figures(mc_results, mc_stats, validation_df, validation_summary):
    """Create publication-quality figures optimized for Colab display."""

    display(HTML("""
    <div class="output-section">
    <h3>🎨 Generating Publication-Quality Figures</h3>
    </div>
    """))

    # Create output directory for figures
    figures_dir = os.path.join(OUTPUT_DIR, 'figures')
    os.makedirs(figures_dir, exist_ok=True)

    # ============================================
    # FIGURE 1: HYSTERESIS LOOPS
    # ============================================
    display(HTML("<h4>📈 Figure 1: Magnetic Hysteresis Loops</h4>"))

    fig1, (ax1, ax1b) = plt.subplots(1, 2, figsize=(12, 4.5))

    H = mc_results['H']
    ja_healthy = RigorousJilesAtherton(Ms=1.71e6, a=50, k=280)
    ja_damaged = RigorousJilesAtherton(Ms=1.60e6, a=65, k=700)

    B_h, _ = ja_healthy.solve(H)
    B_d, _ = ja_damaged.solve(H)

    # Full loop
    plot_range = slice(-1600, None)
    H_plot = H[plot_range] / 1000

    ax1.plot(H_plot, B_h[plot_range], color='#003f5c', lw=2.5,
             label='Healthy (BOL)', alpha=0.9)
    ax1.plot(H_plot, B_d[plot_range], color='#ff6361', lw=2.5,
             label='Irradiated (60 yr)', alpha=0.9, linestyle='--')

    ax1.set_xlabel('Magnetic Field, H (kA/m)', fontweight='bold')
    ax1.set_ylabel('Magnetic Flux Density, B (T)', fontweight='bold')
    ax1.set_title('Radiation-Induced Magnetic Hardening', fontweight='bold')
    ax1.grid(True, alpha=0.2, linestyle='--')
    ax1.legend(fontsize=9, framealpha=0.95)
    ax1.axhline(0, color='k', lw=0.5, alpha=0.3)
    ax1.axvline(0, color='k', lw=0.5, alpha=0.3)

    # Zoomed view
    zoom_range = slice(-800, -400)
    H_zoom = H[zoom_range] / 1000
    ax1b.plot(H_zoom, B_h[zoom_range], color='#003f5c', lw=2.5)
    ax1b.plot(H_zoom, B_d[zoom_range], color='#ff6361', lw=2.5, linestyle='--')
    ax1b.set_xlabel('H (kA/m)', fontweight='bold')
    ax1b.set_ylabel('B (T)', fontweight='bold')
    ax1b.set_title('Zoom: Coercivity Region', fontweight='bold')
    ax1b.grid(True, alpha=0.2)

    plt.tight_layout()
    fig1.savefig(os.path.join(figures_dir, 'Fig1_Hysteresis_Loops.pdf'), dpi=300)
    fig1.savefig(os.path.join(figures_dir, 'Fig1_Hysteresis_Loops.png'), dpi=300)
    plt.show()
    plt.close(fig1)

    # ============================================
    # FIGURE 2: PROPERTY CHANGES
    # ============================================
    display(HTML("<h4>📊 Figure 2: Property Changes</h4>"))

    fig2, ax2 = plt.subplots(1, 1, figsize=(8, 5))

    properties = ['Hc', 'Br', 'mu_max', 'loss']
    labels = ['Coercivity\nH$_c$', 'Remanence\nB$_r$', 'Permeability\nμ$_{max}$', 'Hysteresis\nLoss']
    changes = [mc_stats[p]['change_mean'] for p in properties]
    errors = [mc_stats[p]['change_std'] for p in properties]
    colors = ['#003f5c', '#58508d', '#bc5090', '#ffa600']

    y_pos = np.arange(len(labels))
    bars = ax2.barh(y_pos, changes, xerr=errors,
                   color=colors, alpha=0.8, capsize=4,
                   edgecolor='black', linewidth=1.0)

    ax2.set_yticks(y_pos)
    ax2.set_yticklabels(labels, fontsize=10)
    ax2.set_xlabel('Change Relative to BOL (%)', fontweight='bold')
    ax2.set_title('Magnetic Property Evolution Due to Irradiation', fontweight='bold')
    ax2.axvline(0, color='k', lw=1, ls='--', alpha=0.5)
    ax2.grid(True, alpha=0.2, axis='x')

    # Add value labels
    for bar, val, err in zip(bars, changes, errors):
        width = bar.get_width()
        offset = 3 if width > 0 else -15
        ax2.text(width + offset, bar.get_y() + bar.get_height()/2,
                f'{val:+.1f}±{err:.1f}%',
                va='center', fontsize=9, fontweight='bold')

    plt.tight_layout()
    fig2.savefig(os.path.join(figures_dir, 'Fig2_Property_Changes.pdf'), dpi=300)
    fig2.savefig(os.path.join(figures_dir, 'Fig2_Property_Changes.png'), dpi=300)
    plt.show()
    plt.close(fig2)

    # ============================================
    # FIGURE 3: COERCIVITY DISTRIBUTION
    # ============================================
    display(HTML("<h4>📊 Figure 3: Coercivity Distributions</h4>"))

    fig3, ax3 = plt.subplots(1, 1, figsize=(8, 5))

    Hc_healthy = mc_results['healthy']['Hc'].values
    Hc_damaged = mc_results['damaged']['Hc'].values

    ax3.hist(Hc_healthy, bins=25, alpha=0.5, color='#003f5c',
            edgecolor='black', linewidth=0.5, label='Healthy (BOL)', density=True)
    ax3.hist(Hc_damaged, bins=25, alpha=0.5, color='#ff6361',
            edgecolor='black', linewidth=0.5, label='Irradiated (60 yr)', density=True)

    # Fit normal distributions
    mu_h, std_h = np.mean(Hc_healthy), np.std(Hc_healthy)
    mu_d, std_d = np.mean(Hc_damaged), np.std(Hc_damaged)

    x = np.linspace(min(Hc_healthy.min(), Hc_damaged.min()),
                   max(Hc_healthy.max(), Hc_damaged.max()), 200)

    ax3.plot(x, norm.pdf(x, mu_h, std_h), color='#003f5c', lw=2,
            label=f'Healthy: μ={mu_h:.0f} A/m, σ={std_h:.0f} A/m')
    ax3.plot(x, norm.pdf(x, mu_d, std_d), color='#ff6361', lw=2, linestyle='--',
            label=f'Irradiated: μ={mu_d:.0f} A/m, σ={std_d:.0f} A/m')

    ax3.set_xlabel('Coercivity, H$_c$ (A/m)', fontweight='bold')
    ax3.set_ylabel('Probability Density', fontweight='bold')
    ax3.set_title('Statistical Separation of Coercivity Distributions', fontweight='bold')
    ax3.legend(fontsize=9, framealpha=0.95)
    ax3.grid(True, alpha=0.2)

    plt.tight_layout()
    fig3.savefig(os.path.join(figures_dir, 'Fig3_Coercivity_Distributions.pdf'), dpi=300)
    fig3.savefig(os.path.join(figures_dir, 'Fig3_Coercivity_Distributions.png'), dpi=300)
    plt.show()
    plt.close(fig3)

    # ============================================
    # FIGURE 4: DPA EVOLUTION
    # ============================================
    display(HTML("<h4>📈 Figure 4: DPA Evolution</h4>"))

    fig4, ax4 = plt.subplots(1, 1, figsize=(8, 5))

    fluence_range = np.logspace(19, 23, 100)
    nrt_model = NRTDamageModel()

    dpa_values = nrt_model.calculate_dpa(fluence_range, E_n=1.0)
    degradation = nrt_model.degradation_factor(dpa_values)

    ax4.loglog(fluence_range, degradation * 100, color='#003f5c', lw=2.5,
              label='Magnetization Retention')
    ax4.loglog(fluence_range, (1/degradation) * 100, color='#ff6361', lw=2.5,
              label='Coercivity Increase (1/D)', linestyle='--')

    # Mark operating points
    fluence_60yr = 1e21
    dpa_60yr = nrt_model.calculate_dpa(fluence_60yr, E_n=1.0)
    deg_60yr = nrt_model.degradation_factor(dpa_60yr)

    ax4.axvline(fluence_60yr, color='#2ca02c', ls=':', lw=2, alpha=0.7,
               label=f'60 yr Operation\n({fluence_60yr:.0e} n/cm²)')
    ax4.scatter([fluence_60yr], [deg_60yr * 100],
               color='#2ca02c', s=120, zorder=10, marker='*', edgecolors='black', linewidth=1)

    ax4.set_xlabel('Neutron Fluence (n/cm²)', fontweight='bold')
    ax4.set_ylabel('Property Relative to BOL (%)', fontweight='bold')
    ax4.set_title('NRT Damage Model: Property Evolution with Fluence', fontweight='bold')
    ax4.legend(fontsize=9, framealpha=0.95)
    ax4.grid(True, alpha=0.2, which='both')

    plt.tight_layout()
    fig4.savefig(os.path.join(figures_dir, 'Fig4_DPA_Evolution.pdf'), dpi=300)
    fig4.savefig(os.path.join(figures_dir, 'Fig4_DPA_Evolution.png'), dpi=300)
    plt.show()
    plt.close(fig4)

    # ============================================
    # FIGURE 5: EXPERIMENTAL VALIDATION
    # ============================================
    display(HTML("<h4>✅ Figure 5: Experimental Validation</h4>"))

    fig5, ax5 = plt.subplots(1, 1, figsize=(9, 5))

    y_pos = np.arange(len(validation_df))
    labels = validation_df['Property'].tolist()
    units = validation_df['Units'].tolist()

    # Create combined labels
    combined_labels = [f'{label} ({unit})' for label, unit in zip(labels, units)]

    # Plot experimental data with error bars
    ax5.errorbar(validation_df['Experimental'], y_pos,
                xerr=validation_df['Exp_Std'],
                fmt='o', color='#003f5c', markersize=8,
                capsize=4, label='Experimental ± 1σ',
                alpha=0.8, linewidth=1.5)

    # Plot simulation results
    ax5.scatter(validation_df['Simulated'], y_pos,
               color='#ff6361', s=100, marker='s',
               label='Simulation', zorder=10,
               edgecolors='black', linewidth=1.0)

    ax5.set_yticks(y_pos)
    ax5.set_yticklabels(combined_labels, fontsize=10)
    ax5.set_xlabel('Value', fontweight='bold')
    ax5.set_title(f'Model Validation: {validation_summary["status"]}',
                 fontweight='bold', fontsize=12, color='#2E5090')
    ax5.legend(fontsize=9, framealpha=0.95, loc='lower right')
    ax5.grid(True, alpha=0.2, axis='x')

    # Add Z-score annotations
    for i, row in validation_df.iterrows():
        ax5.annotate(f'z={row["Z_Score"]:.2f}σ',
                    xy=(row['Simulated'], i),
                    xytext=(5, 0), textcoords='offset points',
                    fontsize=9, va='center')

    plt.tight_layout()
    fig5.savefig(os.path.join(figures_dir, 'Fig5_Experimental_Validation.pdf'), dpi=300)
    fig5.savefig(os.path.join(figures_dir, 'Fig5_Experimental_Validation.png'), dpi=300)
    plt.show()
    plt.close(fig5)

    # ============================================
    # FIGURE 6: SUMMARY DASHBOARD
    # ============================================
    display(HTML("<h4>📋 Figure 6: Summary Dashboard</h4>"))

    fig6 = plt.figure(figsize=(14, 10))
    gs = gridspec.GridSpec(3, 3, figure=fig6, hspace=0.4, wspace=0.3)

    # Panel A: Hysteresis
    ax6a = fig6.add_subplot(gs[0, :2])
    ax6a.plot(H_plot, B_h[plot_range], color='#003f5c', lw=2)
    ax6a.plot(H_plot, B_d[plot_range], color='#ff6361', lw=2, linestyle='--')
    ax6a.set_xlabel('H (kA/m)', fontsize=10)
    ax6a.set_ylabel('B (T)', fontsize=10)
    ax6a.set_title('Magnetic Hysteresis', fontweight='bold')
    ax6a.grid(True, alpha=0.2)

    # Panel B: Property Changes
    ax6b = fig6.add_subplot(gs[0, 2])
    ax6b.barh(range(2), [changes[0], changes[1]],
             xerr=[errors[0], errors[1]], color=['#003f5c', '#58508d'], alpha=0.8)
    ax6b.set_yticks(range(2))
    ax6b.set_yticklabels(['Coercivity', 'Remanence'])
    ax6b.set_xlabel('Change (%)')
    ax6b.set_title('Key Changes', fontweight='bold')
    ax6b.grid(True, alpha=0.2, axis='x')

    # Panel C: Distributions
    ax6c = fig6.add_subplot(gs[1, 0])
    ax6c.hist(Hc_healthy, bins=20, alpha=0.5, color='#003f5c', density=True, label='Healthy')
    ax6c.hist(Hc_damaged, bins=20, alpha=0.5, color='#ff6361', density=True, label='Irradiated')
    ax6c.set_xlabel('H$_c$ (A/m)')
    ax6c.set_ylabel('Density')
    ax6c.set_title('Coercivity PDF', fontweight='bold')
    ax6c.legend(fontsize=8)
    ax6c.grid(True, alpha=0.2)

    # Panel D: Validation
    ax6d = fig6.add_subplot(gs[1, 1])
    bars = ax6d.bar(range(len(validation_df)), validation_df['Z_Score'],
                   color=['#4CAF50' if x < 2 else '#FF9800' if x < 3 else '#F44336'
                         for x in validation_df['Z_Score']])
    ax6d.set_xticks(range(len(validation_df)))
    ax6d.set_xticklabels(['Ms', 'Hc', 'ΔHc'], fontsize=9)
    ax6d.set_ylabel('Z-Score (σ)')
    ax6d.set_title('Validation Z-Scores', fontweight='bold')
    ax6d.grid(True, alpha=0.2, axis='y')
    ax6d.axhline(2, color='orange', linestyle='--', alpha=0.7, label='2σ threshold')
    ax6d.axhline(3, color='red', linestyle='--', alpha=0.7, label='3σ threshold')

    # Panel E: Statistical Significance
    ax6e = fig6.add_subplot(gs[1, 2])
    p_value = mc_stats['significance']['p_value']
    bars_e = ax6e.bar(['p-value'], [-np.log10(p_value)], color='#2196F3')
    ax6e.set_ylabel('-log₁₀(p)')
    ax6e.set_title(f'Statistical Significance\np = {p_value:.2e}', fontweight='bold')
    ax6e.grid(True, alpha=0.2, axis='y')
    ax6e.axhline(-np.log10(0.05), color='red', linestyle='--', alpha=0.7, label='p=0.05')
    ax6e.axhline(-np.log10(0.001), color='orange', linestyle='--', alpha=0.7, label='p=0.001')

    # Panel F: Summary Table
    ax6f = fig6.add_subplot(gs[2, :])
    ax6f.axis('tight')
    ax6f.axis('off')

    summary_data = [
        ['Coercivity Increase', f"{mc_stats['Hc']['change_mean']:+.1f}%"],
        ['Remanence Change', f"{mc_stats['Br']['change_mean']:+.1f}%"],
        ['Statistical Significance', f"p = {mc_stats['significance']['p_value']:.2e}"],
        ['Validation Status', validation_summary['status']],
        ['Mean Z-Score', f"{validation_summary['mean_z_score']:.2f}σ"],
        ['Confidence Level', f"{validation_summary['confidence']}%" ]
    ]

    table = ax6f.table(cellText=summary_data,
                      colLabels=['Metric', 'Value'],
                      cellLoc='center',
                      loc='center',
                      colWidths=[0.4, 0.3])
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1, 2)

    for i in range(len(summary_data) + 1):
        for j in range(2):
            if i == 0:
                table[(i, j)].set_facecolor('#2E5090')
                table[(i, j)].set_text_props(weight='bold', color='white')
            else:
                if i % 2 == 0:
                    table[(i, j)].set_facecolor('#F5F5F5')

    plt.suptitle('RPV Radiation Damage Analysis Dashboard', fontweight='bold', fontsize=14)
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    fig6.savefig(os.path.join(figures_dir, 'Fig6_Summary_Dashboard.pdf'), dpi=300)
    fig6.savefig(os.path.join(figures_dir, 'Fig6_Summary_Dashboard.png'), dpi=300)
    plt.show()
    plt.close(fig6)

    # Generate LaTeX template
    latex_template = f"""
% ============================================================================
% LaTeX Template for Publication Figures
% Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
% ============================================================================

\\documentclass{{article}}
\\usepackage{{graphicx}}
\\usepackage{{subcaption}}
\\usepackage{{booktabs}}
\\usepackage{{siunitx}}

\\begin{{document}}

\\section*{{Figure Captions}}

\\subsection*{{Figure 1: Magnetic Hysteresis Loops}}
Radiation-induced magnetic hardening in SA-508 RPV steel after 60-year operation.

\\subsection*{{Figure 2: Property Changes}}
Changes in magnetic properties due to neutron irradiation.

\\subsection*{{Figure 3: Coercivity Distributions}}
Statistical separation of healthy and irradiated material.

\\subsection*{{Figure 4: DPA Evolution}}
Property evolution with neutron fluence from NRT damage model.

\\subsection*{{Figure 5: Experimental Validation}}
Model validation against experimental literature data.

\\subsection*{{Figure 6: Summary Dashboard}}
Comprehensive overview of simulation results.

\\end{{document}}
"""

    latex_path = os.path.join(figures_dir, 'LaTeX_Figure_Template.tex')
    with open(latex_path, 'w') as f:
        f.write(latex_template)

    display(HTML(f"""
    <div class="output-section">
    <h3>✅ Figures Generated Successfully</h3>
    <p><strong>Location:</strong> {figures_dir}</p>
    <p><strong>Files created:</strong></p>
    <ul>
        <li>Fig1_Hysteresis_Loops.pdf/png</li>
        <li>Fig2_Property_Changes.pdf/png</li>
        <li>Fig3_Coercivity_Distributions.pdf/png</li>
        <li>Fig4_DPA_Evolution.pdf/png</li>
        <li>Fig5_Experimental_Validation.pdf/png</li>
        <li>Fig6_Summary_Dashboard.pdf/png</li>
        <li>LaTeX_Figure_Template.tex</li>
    </ul>
    </div>
    """))

    return figures_dir


# ==========================================
# 5. COLAB-SPECIFIC UTILITIES
# ==========================================

def create_colab_download_button(files_to_download):
    """Create download buttons for Colab."""
    display(HTML("""
    <div class="output-section">
    <h3>📥 Download Results</h3>
    </div>
    """))

    # Create a zip file of all outputs
    zip_path = '/content/rpv_simulation_results.zip'
    with zipfile.ZipFile(zip_path, 'w') as zipf:
        for root, dirs, files in os.walk(OUTPUT_DIR):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, OUTPUT_DIR)
                zipf.write(file_path, arcname)

    # Create download button
    # The local import here is causing the UnboundLocalError
    # It's not needed as display, HTML are already globally imported
    display(HTML(f"""
    <div style="background: #e8f5e9; padding: 15px; border-radius: 5px; margin: 10px 0;">
    <h4 style="color: #2e7d32; margin: 0 0 10px 0;">Download All Results</h4>
    <p>All figures, data, and reports have been packaged into a single ZIP file.</p>
    <a href="/files/{zip_path}" download="rpv_simulation_results.zip">
        <button style="background: #4CAF50; color: white; padding: 10px 20px;
                      border: none; border-radius: 5px; cursor: pointer; font-size: 14px;">
            📦 Download Complete Results Package
        </button>
    </a>
    <p style="margin-top: 10px; font-size: 12px; color: #666;">
    Includes: All PDF/PNG figures, CSV data files, LaTeX templates, and reports
    </p>
    </div>
    """))

def display_interactive_results(mc_stats, validation_summary, validation_df):
    """Display interactive results dashboard in Colab."""

    # Create a beautiful summary dashboard
    summary_html = f"""
    <div style="background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                padding: 20px; border-radius: 10px; margin: 20px 0;">
        <h2 style="color: #1a237e; margin-top: 0;">📊 Simulation Results Summary</h2>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">

            <div style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="color: #003f5c; margin-top: 0;">🧲 Magnetic Properties</h3>
                <p><strong>Coercivity Increase:</strong> <span style="color: #ff6361; font-weight: bold;">{mc_stats['Hc']['change_mean']:+.1f}%</span></p>
                <p><strong>Remanence Change:</strong> <span style="color: #58508d; font-weight: bold;">{mc_stats['Br']['change_mean']:+.1f}%</span></p>
                <p><strong>Permeability Change:</strong> <span style="color: #bc5090; font-weight: bold;">{mc_stats['mu_max']['change_mean']:+.1f}%</span></p>
            </div>

            <div style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="color: #003f5c; margin-top: 0;">📈 Statistical Significance</h3>
                <p><strong>t-statistic:</strong> {mc_stats['significance']['t_statistic']:.2f}</p>
                <p><strong>p-value:</strong> <span style="{'color: #4CAF50;' if mc_stats['significance']['p_value'] < 0.001 else 'color: #FF9800;'}">{mc_stats['significance']['p_value']:.2e}</span></p>
                <p><strong>Significant:</strong> {'✅ YES' if mc_stats['significance']['significant'] else '⚠️ NO'}</p>
            </div>

            <div style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="color: #003f5c; margin-top: 0;">✅ Model Validation</h3>
                <p><strong>Status:</strong> {validation_summary['status']}</p>
                <p><strong>Mean Z-Score:</strong> {validation_summary['mean_z_score']:.2f}σ</p>
                <p><strong>Confidence:</strong> {validation_summary['confidence']}%</p>
            </div>

        </div>
    </div>
    """

    display(HTML(summary_html))

    # Display validation table
    display(Markdown("### 📋 Experimental Validation Results"))
    display(validation_df.style
            .background_gradient(subset=['Z_Score'], cmap='RdYlGn_r')
            .format({'Simulated': '{:.2f}', 'Experimental': '{:.2f}', 'Exp_Std': '{:.2f}', 'Z_Score': '{:.2f}'})
            .set_properties(**{'text-align': 'center'}))

    # Display Monte Carlo confidence intervals
    display(Markdown("### 🎯 Monte Carlo Confidence Intervals (95%)"))
    ci_data = []
    for prop in ['Hc', 'Br', 'mu_max']:
        ci_low, ci_high = mc_stats[prop]['change_ci']
        ci_data.append([prop, f"{ci_low:.1f}%", f"{ci_high:.1f}%", f"{mc_stats[prop]['change_mean']:.1f}%"])

    ci_df = pd.DataFrame(ci_data, columns=['Property', 'CI Lower', 'CI Upper', 'Mean'])
    display(ci_df.style.set_properties(**{'text-align': 'center'}))


# ==========================================
# 6. MAIN EXECUTION FOR COLAB
# ==========================================

def run_colab_simulation():
    """Main execution function for Colab."""

    display(HTML("""
    <div class="output-section">
    <h2>🚀 Starting RPV Radiation Damage Simulation</h2>
    </div>
    """))

    # 1. Monte Carlo simulation
    display(HTML("<h3>🔢 Step 1: Monte Carlo Uncertainty Quantification</h3>"))
    mc_sim = RigorousMonteCarloUQ(n_trials=500)
    mc_results = mc_sim.run(base_fluence=1e21, verbose=True)
    mc_stats = mc_sim.compute_statistics()

    # 2. Experimental validation
    display(HTML("<h3>✅ Step 2: Experimental Validation</h3>"))
    validator = ExperimentalValidation()
    validation_df, validation_summary = validator.validate_model(mc_results)

    # 3. Generate figures
    display(HTML("<h3>🎨 Step 3: Generating Publication Figures</h3>"))
    figures_dir = create_publication_figures(mc_results, mc_stats, validation_df, validation_summary)

    # 4. Generate reports
    display(HTML("<h3>📄 Step 4: Generating Reports</h3>"))

    # Save data files
    data_dir = os.path.join(OUTPUT_DIR, 'data')
    os.makedirs(data_dir, exist_ok=True)

    # Save validation data
    validation_df.to_csv(os.path.join(data_dir, 'validation_data.csv'), index=False)

    # Save Monte Carlo statistics
    stats_data = []
    for prop in ['Hc', 'Br', 'mu_max', 'loss']:
        stats_data.append({
            'Property': prop,
            'Healthy_Mean': mc_stats[prop]['healthy_mean'],
            'Healthy_Std': mc_stats[prop]['healthy_std'],
            'Damaged_Mean': mc_stats[prop]['damaged_mean'],
            'Damaged_Std': mc_stats[prop]['damaged_std'],
            'Change_Mean': mc_stats[prop]['change_mean'],
            'Change_Std': mc_stats[prop]['change_std'],
            'CI_Lower': mc_stats[prop]['change_ci'][0],
            'CI_Upper': mc_stats[prop]['change_ci'][1]
        })

    pd.DataFrame(stats_data).to_csv(os.path.join(data_dir, 'monte_carlo_statistics.csv'), index=False)

    # Generate comprehensive report
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    report_content = f"""
    ========================================================================
    RPV RADIATION DAMAGE SIMULATION REPORT
    ========================================================================

    Generated: {timestamp}

    SUMMARY
    -------
    • Coercivity increase: {mc_stats['Hc']['change_mean']:.1f}% ± {mc_stats['Hc']['change_std']:.1f}%
    • Statistical significance: p = {mc_stats['significance']['p_value']:.2e}
    • Validation status: {validation_summary['status']}
    • Validation confidence: {validation_summary['confidence']}%

    FILES GENERATED
    ---------------
    1. Figures (in {figures_dir}):
       - Fig1_Hysteresis_Loops.pdf/png
       - Fig2_Property_Changes.pdf/png
       - Fig3_Coercivity_Distributions.pdf/png
       - Fig4_DPA_Evolution.pdf/png
       - Fig5_Experimental_Validation.pdf/png
       - Fig6_Summary_Dashboard.pdf/png

    2. Data files (in {data_dir}):
       - validation_data.csv
       - monte_carlo_statistics.csv

    3. Templates:
       - LaTeX_Figure_Template.tex

    VALIDATION RESULTS
    ------------------
    {validation_df.to_string(index=False)}

    ========================================================================
    """

    report_path = os.path.join(OUTPUT_DIR, 'simulation_report.txt')
    with open(report_path, 'w') as f:
        f.write(report_content)

    # Create README
    readme_content = f"""
    # RPV Radiation Damage Simulation - Google Colab
    ## Complete Simulation Package

    ### Overview
    This package contains all results from the rigorous multiphysics simulation
    of radiation-induced magnetic property changes in Reactor Pressure Vessel steel.

    ### Key Results
    • Coercivity increase after 60 years: {mc_stats['Hc']['change_mean']:.1f}%
    • Statistical significance: p = {mc_stats['significance']['p_value']:.2e}
    • Model validation: {validation_summary['status']}

    ### Directory Structure
    {OUTPUT_DIR}/
    ├── figures/           # Publication-quality figures (PDF & PNG)
    ├── data/             # CSV data files
    ├── simulation_report.txt
    └── README.txt

    ### How to Use
    1. Download the complete package using the download button
    2. Use PDF figures directly in publications
    3. Modify LaTeX template for your paper
    4. Analyze CSV data in Excel or Python

    Generated: {timestamp}
    """

    with open(os.path.join(OUTPUT_DIR, 'README.txt'), 'w') as f:
        f.write(readme_content)

    # 5. Display interactive results
    display_interactive_results(mc_stats, validation_summary, validation_df)

    # 6. Create download button
    create_colab_download_button(OUTPUT_DIR)

    # Final summary
    display(HTML(f"""
    <div style="background: linear-gradient(135deg, #1a237e 0%, #283593 100%);
                color: white; padding: 25px; border-radius: 10px; margin: 25px 0;">
        <h2 style="color: white; margin-top: 0;">🎉 Simulation Complete!</h2>
        <p>All analyses completed successfully. The simulation package includes:</p>
        <ul>
            <li>✅ 6 publication-quality figures (PDF & PNG)</li>
            <li>✅ Complete statistical analysis</li>
            <li>✅ Experimental validation results</li>
            <li>✅ LaTeX templates for publication</li>
            <li>✅ Downloadable ZIP package</li>
        </ul>
        <p><strong>Total files generated:</strong> {sum([len(files) for _, _, files in os.walk(OUTPUT_DIR)])}</p>
        <p><strong>Output directory:</strong> {OUTPUT_DIR}</p>
    </div>
    """))

    return mc_results, mc_stats, validation_df, validation_summary


# ==========================================
# 7. RUN THE SIMULATION
# ==========================================

if __name__ == "__main__":
    # Run the complete simulation
    results = run_colab_simulation()

    # Provide direct Colab cell execution instructions
    display(HTML("""
    <div style="background: #fff3e0; padding: 15px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #ff9800;">
    <h3>📝 How to Re-run or Modify</h3>
    <p>To run this simulation again or modify parameters:</p>
    <ol>
        <li>Change Monte Carlo trials: <code>mc_sim = RigorousMonteCarloUQ(n_trials=1000)</code></li>
        <li>Change neutron fluence: <code>mc_results = mc_sim.run(base_fluence=5e20)</code></li>
        <li>Modify material properties in the Physics Models section</li>
        <li>Customize figures by editing the visualization functions</li>
    </ol>
    </div>
    """))
# -*- coding: utf-8 -*-
"""Corrected thermal survivability figure.

Fault in the notebook (cell 0): the safety margin was computed as
    safety_margin = signal[idx] - total_noise[idx]
a difference of two quantities in arbitrary units, and then printed and
annotated as decibels. A margin in decibels is 20*log10(signal/noise).
The published value of 48.4 dB is that arithmetic difference, not a ratio.

Second fault: the signal was not normalised to its value at room temperature,
so the left panel started at 80 per cent rather than 100 per cent and did not
match the thermal derating factor quoted in the manuscript's own table.
"""
import sys
sys.path.insert(0, '/home/claude/rpv/refig')
import tbstyle                                   # house style, then plain savefig
import matplotlib as mpl
mpl.figure.Figure.savefig = tbstyle._orig_fig_savefig
import matplotlib.pyplot as plt
import numpy as np

T_C = 770 + 273.15
T_OP = 290 + 273.15
T_REF = 293.0
N_EXP = 0.67


def thermal_degradation(T, T_C=T_C, n=N_EXP):
    T = np.asarray(T, dtype=float)
    return np.where(T < T_C, np.clip(1 - T / T_C, 0, None) ** n, 0.0)


T = np.linspace(T_REF, T_C - 50, 400)
signal = thermal_degradation(T) / thermal_degradation(T_REF) * 100.0   # per cent of BOL
thermal_noise = 5 * np.sqrt((T - T_REF) / 200)
amplifier_noise = 3.2
reactor_noise = 2.0 * (T / T_OP) ** 1.5
noise = thermal_noise + amplifier_noise + reactor_noise

snr = signal / noise
margin_db = 20 * np.log10(snr)                    # the corrected definition
i_op = int(np.argmin(np.abs(T - T_OP)))

thr_snr = 10.0
thr_db = 20 * np.log10(thr_snr)
cross = T[np.argmax(snr < thr_snr)] - 273.15 if np.any(snr < thr_snr) else None

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.6))
ax1.plot(T - 273.15, signal, color='black', lw=1.6, label='Magnetic signal')
ax1.plot(T - 273.15, noise, color='#6e6e6e', lw=1.6, ls=(0, (5, 2)), label='Total system noise')
ax1.fill_between(T - 273.15, noise, signal, where=(signal > noise),
                 facecolor='#e6e6e6', edgecolor='#999999', hatch='////', lw=0.4, alpha=0.7)
ax1.axvline(T_OP - 273.15, color='#555555', lw=1.0, ls=(0, (2, 2)))
ax1.annotate('operating temperature\n290 $^\\circ$C', xy=(T_OP - 273.15, 88),
             xytext=(T_OP - 273.15 + 40, 92), fontsize=8,
             arrowprops=dict(arrowstyle='-|>', color='#333333', lw=0.8))
ax1.set_xlabel('Temperature ($^\\circ$C)'); ax1.set_ylabel('Level (per cent of BOL signal)')
ax1.set_title('Signal and noise against temperature'); ax1.set_ylim(0, 110)
ax1.legend(loc='upper right', fontsize=8, frameon=True, edgecolor='#666666')
ax1.grid(True, color='#c8c8c8', ls=':', lw=0.5)

ax2.plot(T - 273.15, margin_db, color='black', lw=1.6, label='Margin, $20\\log_{10}(S/N)$')
ax2.axhline(thr_db, color='#6e6e6e', lw=1.3, ls=(0, (5, 2)),
            label='Detection threshold, SNR = 10 (20 dB)')
ax2.axvline(T_OP - 273.15, color='#555555', lw=1.0, ls=(0, (2, 2)))
ax2.plot([T_OP - 273.15], [margin_db[i_op]], marker='o', mfc='white', mec='black', mew=1.2)
ax2.annotate('%.1f dB at 290 $^\\circ$C' % margin_db[i_op],
             xy=(T_OP - 273.15, margin_db[i_op]), xytext=(T_OP - 273.15 + 45, margin_db[i_op] + 6),
             fontsize=8, arrowprops=dict(arrowstyle='-|>', color='#333333', lw=0.8),
             bbox=dict(boxstyle='round,pad=0.3', fc='#f5f5f5', ec='#555555', lw=0.6))
ax2.set_xlabel('Temperature ($^\\circ$C)'); ax2.set_ylabel('Detection margin (dB)')
ax2.set_title('Detection margin against temperature')
ax2.legend(loc='upper right', fontsize=8, frameon=True, edgecolor='#666666')
ax2.grid(True, color='#c8c8c8', ls=':', lw=0.5)

plt.tight_layout()
import os
os.makedirs('/home/claude/rpv/corrected/figs', exist_ok=True)
fig.savefig('/home/claude/rpv/corrected/figs/thermal_snr_safety.png', dpi=400,
            bbox_inches='tight', facecolor='white')

print('signal at 25 C            : %.1f per cent' % signal[0])
print('signal at 290 C           : %.1f per cent  (derating factor %.3f)'
      % (signal[i_op], signal[i_op] / signal[0]))
print('SNR at 290 C              : %.2f' % snr[i_op])
print('margin at 290 C, corrected: %.1f dB' % margin_db[i_op])
print('published value           : 48.4, which is signal minus noise in arbitrary units,')
print('                            not a decibel ratio')
print('threshold SNR = 10        : %.1f dB' % thr_db)
print('SNR falls below 10 at     : %.0f C' % cross if cross else 'never')

# -*- coding: utf-8 -*-
"""Figures regenerated from the corrected model, in the manuscript's house style."""
import sys, json
sys.path.insert(0, '/home/claude/rpv/refig'); sys.path.insert(0, '/home/claude/rpv/corrected')
import tbstyle
import matplotlib as mpl
mpl.figure.Figure.savefig = tbstyle._orig_fig_savefig
import matplotlib.pyplot as plt
import numpy as np, pandas as pd
from scipy import stats
from rpv_model import *

OUT = '/home/claude/rpv/corrected/figs'
import os; os.makedirs(OUT, exist_ok=True)
h = pd.read_csv('mc_healthy.csv'); d = pd.read_csv('mc_irradiated.csv')
S = json.load(open('mc_summary.json'))

def save(fig, name):
    fig.savefig(os.path.join(OUT, name), dpi=400, bbox_inches='tight', facecolor='white')
    plt.close(fig); print('  wrote', name)

# ---------------------------------------------- Fig: hysteresis loops (4.4)
nrt = NRTDamageModel()
H, first = graded_sweep()
dpa = float(nrt.calculate_dpa(1e21, 1.0))
df = float(nrt.degradation_factor(dpa)); km = float(pinning_multiplier(dpa))
Bh, _ = JilesAtherton().solve(H)
Bd, _ = JilesAtherton(Ms=1.71e6*df, a=1100*(1+0.3*(1-df)), k=750*km).solve(H)
fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.2))
for ax in (a1, a2):
    ax.plot(H[first:]/1000, Bh[first:], color='black', lw=1.5, label='Healthy (BOL)')
    ax.plot(H[first:]/1000, Bd[first:], color='#6e6e6e', lw=1.5, ls=(0, (5, 2)),
            label='Irradiated (60 yr, %.1f dpa)' % dpa)
    ax.axhline(0, color='#bbbbbb', lw=0.6); ax.axvline(0, color='#bbbbbb', lw=0.6)
    ax.set_xlabel('Magnetic field, $H$ (kA/m)'); ax.grid(True, color='#c8c8c8', ls=':', lw=0.5)
a1.set_ylabel('Flux density, $B$ (T)'); a1.set_title('Major hysteresis loop')
a1.legend(loc='lower right', fontsize=8, edgecolor='#666666')
a2.set_xlim(-3, 3); a2.set_ylim(-1.2, 1.2); a2.set_title('Coercive region')
a2.set_ylabel('$B$ (T)')
plt.tight_layout(); save(fig, 'hysteresis_hardening.png')

# ------------------------------------- Fig: coercivity distributions (5.3)
fig, ax = plt.subplots(figsize=(7.5, 4.4))
lo = min(h.Hc.min(), d.Hc.min())*0.9; hi = max(h.Hc.max(), d.Hc.max())*1.05
bins = np.linspace(lo, hi, 60)
ax.hist(h.Hc, bins=bins, density=True, facecolor='#d9d9d9', edgecolor='black',
        lw=0.6, label='Healthy: $\\mu$=%.0f, $\\sigma$=%.0f A/m' % (h.Hc.mean(), h.Hc.std()))
ax.hist(d.Hc, bins=bins, density=True, facecolor='white', edgecolor='black', lw=0.6,
        hatch='////', label='Irradiated: $\\mu$=%.0f, $\\sigma$=%.0f A/m' % (d.Hc.mean(), d.Hc.std()))
ax.set_xlabel('Coercivity, $H_c$ (A/m)'); ax.set_ylabel('Probability density')
ax.set_title('Separation of coercivity distributions')
ax.legend(fontsize=8, edgecolor='#666666'); ax.grid(True, color='#c8c8c8', ls=':', lw=0.5)
plt.tight_layout(); save(fig, 'statistical_separation.png')

# --------------------------------------- Fig: relative property changes (5.2)
names = [('Hc','Coercivity $H_c$'), ('Br','Remanence $B_r$'),
         ('mu_max','Peak permeability'), ('loss','Hysteresis loss')]
vals = [S[k]['change_pct'] for k,_ in names]
errs = [abs(S[k]['irradiated_sd']/S[k]['healthy_mean']*100) for k,_ in names]
fig, ax = plt.subplots(figsize=(7.5, 4.2))
y = np.arange(len(names))
fills = ['#d9d9d9', '#ffffff', '#8c8c8c', '#3d3d3d']
hatches = ['', '////', '\\\\\\\\', 'xxxx']
for i,(v,e) in enumerate(zip(vals, errs)):
    ax.barh(y[i], v, xerr=e, height=0.6, facecolor=fills[i], hatch=hatches[i],
            edgecolor='black', lw=0.8, error_kw=dict(ecolor='#333333', lw=0.8, capsize=3))
    ax.text(v + (6 if v>0 else -6), y[i], '%+.1f%%' % v, va='center',
            ha='left' if v>0 else 'right', fontsize=9)
ax.set_yticks(y); ax.set_yticklabels([n for _,n in names])
ax.axvline(0, color='black', lw=0.8)
ax.set_xlabel('Change relative to beginning of life (per cent)')
ax.set_title('Magnetic property evolution after 60 years')
ax.set_xlim(min(vals)-40, max(vals)+40)
ax.grid(True, axis='x', color='#c8c8c8', ls=':', lw=0.5)
plt.tight_layout(); save(fig, 'property_evolution_bar.png')

# ------------------------------------------- Fig: NRT damage evolution (2.1)
F = np.logspace(19, 23, 200)
dp = nrt.calculate_dpa(F, 1.0)
ms_ret = nrt.degradation_factor(dp) * 100
hc_rise = pinning_multiplier(dp) * 100
fig, ax = plt.subplots(figsize=(7.5, 4.4))
ax.semilogx(F, ms_ret, color='black', lw=1.6, label='Saturation magnetization retained')
ax.semilogx(F, hc_rise, color='#6e6e6e', lw=1.6, ls=(0, (5, 2)), label='Pinning parameter $k$')
ax.axvline(1e21, color='#555555', lw=1.0, ls=(0, (1, 1.5)))
ax.annotate('60 yr operation\n$10^{21}$ n/cm$^2$', xy=(1e21, 250), xytext=(1.6e21, 300),
            fontsize=8, arrowprops=dict(arrowstyle='-|>', color='#333333', lw=0.8))
ax.set_xlabel('Neutron fluence (n/cm$^2$)'); ax.set_ylabel('Property relative to BOL (per cent)')
ax.set_title('NRT damage model: property evolution with fluence')
ax.legend(fontsize=8, loc='upper left', edgecolor='#666666')
ax.grid(True, which='both', color='#c8c8c8', ls=':', lw=0.5)
plt.tight_layout(); save(fig, 'nrt_damage_model.png')

print('\ncorrected summary')
for k, n in names:
    s = S[k]
    print('  %-20s %10.4g -> %-10.4g  %+8.2f%%   d=%.2f' %
          (n.replace('$',''), s['healthy_mean'], s['irradiated_mean'], s['change_pct'], s['cohen_d']))

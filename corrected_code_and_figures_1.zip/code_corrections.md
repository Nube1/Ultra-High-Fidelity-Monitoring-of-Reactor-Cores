# Corrections to the simulation code

Eight faults, all found by reading and re-running the notebook in the repository.
Seven are corrected and the model re-run; one is a verification method that cannot
be corrected without deciding what it is meant to test.

The corrected code is in `corrected_code/`. `rpv_model.py` holds the physics,
`run_mc.py` the Monte Carlo, `thermal.py` the thermal figure, `make_figs.py` the
plots. The Monte Carlo results are in `mc_healthy.csv`, `mc_irradiated.csv` and
`mc_summary.json`. Regenerated figures are in `corrected_figures/`.

---

## 1. Displacements per atom divided by the atom density

Cell 20, `NRTDamageModel.calculate_dpa`.

```python
dpa = fluence * sigma_d * nu_nrt / self.N_Fe     # as written
dpa = fluence * sigma_d * nu_nrt                 # corrected
```

`sigma_d` is a microscopic cross-section, so the product is already per atom.
Dividing again by the atom density makes the damage about 23 orders of magnitude
too small. `degradation_factor` then clipped to exactly 1.000000 at every fluence
from 1e19 to 1e23 n/cm2.

Consequence: Figure 2.1 was two flat lines, and the irradiated case in the Monte
Carlo differed from the healthy case only through a hard-coded pinning multiplier.
Neutron transport, fluence sampling and the NRT model contributed nothing to any
reported statistic.

## 2. Field sweep too coarse to resolve the loop

Cell 20, `RigorousMonteCarloUQ.run`. The sweep stepped in 200 A/m. With the
published shape parameter the loop turns over a few hundred A/m, so the Euler
integration stepped straight over the coercive region.

Measured on the published parameters, coercivity moves from 28.7 A/m at the
published 200 A/m step to 131 A/m once converged at 1 A/m, and remanence from
0.39 T to 1.78 T. Both published values were grid artefacts.

Corrected with a graded sweep, 1 A/m where the loop turns and 50 A/m out in
saturation. That agrees with a uniform 1 A/m sweep to within 0.01 per cent and
runs about five times faster.

## 3. Coercivity read off grid points, and off the virgin branch

Cell 20, `extract_properties`.

```python
Hc = np.mean(np.abs(H[zero_crossings]))
```

Two problems. The crossing was snapped to the nearest grid point rather than
interpolated, and the average ran over the virgin branch as well as the major
loop, where the curve passes through the origin.

Consequence: the irradiated coercivity came out with a standard deviation of
exactly zero, which is why Figure 5.3 had no distributions to separate.

## 4. Remanence read at the virgin point

Cell 20, `extract_properties`.

```python
H_zero_idx = np.argmin(np.abs(H))
Br = B[H_zero_idx]
```

The sweep starts at H = 0, so `argmin` always returns index 0, where B is zero by
construction. Remanence was zero in every trial. The "Remanence Change: +0.0%" on
the summary dashboard was this, not a result. Corrected to the field zero crossing
of the major loop.

## 5. Jiles-Atherton parameters do not reproduce the validated coercivity

Cell 20, `RigorousJilesAtherton.__init__`, `a = 50.0`, `k = 280.0`. Converged,
those give a coercivity of about 131 A/m. Table 1 of the manuscript gives 680 A/m
and validates it against a literature range of 600 to 850 A/m.

Recalibrated to `a = 1100`, `k = 750`, which gives 677.6 A/m for a single loop and
676.7 A/m as the Monte Carlo mean. The model now reproduces the number its own
validation table tests, which it previously did not.

## 6. Irradiation entered as a hard-coded constant

Cell 20, `k_base_damaged_ratio = 2.5`, applied regardless of fluence, energy or
damage. Replaced by the manuscript's own constitutive law, written for the pinning
parameter:

```python
k(dpa) = k0 * (1 + XI * (dpa / dpa_sat) ** p)
```

with `p = 0.5` and `XI` set so the multiplier reaches 2.5 at the sixty-year
fluence. The intended end state is unchanged; it now arrives through the physics
rather than by assertion, so fluence genuinely drives the result and the
sensitivity analysis in Section 5 means something.

`K_RATIO_AT_EOL` is a single named constant at the top of `rpv_model.py`. See the
note at the end about its value.

## 7. Thermal safety margin was not a decibel ratio

Cell 0.

```python
safety_margin = signal[idx_op] - total_noise[idx_op]      # as written
margin_db = 20 * np.log10(signal / noise)                 # corrected
```

The published 48.4 "dB" is the arithmetic difference of two quantities in
arbitrary units. A margin in decibels is twenty times the log of their ratio. The
signal was also not normalised to its room-temperature value, so the panel started
at 80 per cent instead of 100 and did not match the derating factor in the
manuscript's own table.

Corrected, the derating factor at 290 C is 0.741, which does match the table's
0.73. See the results section below for what the margin becomes.

## 8. The Lipschitz check is circular

Cell 17, `C_empirical = np.max(ratios)`, followed by a test that every ratio falls
below `C_empirical`. That is true by construction. Appendix F presents this as
verification against a theoretical constant of 14.26, but 14.26 is the maximum of
the same sample. Not corrected, because the fix depends on what bound you want to
test against. As it stands the check should be described as an empirical estimate
of the Lipschitz constant, not a verification.

---

## What the model gives once corrected

Monte Carlo, 2000 trials, seed 42, fluence 1e21 n/cm2 with the same 15 per cent
spread, same parameter uncertainties as the notebook.

| quantity | published | corrected |
|---|---|---|
| damage factor across the run | 1.000000 at every fluence | 0.875 to 0.935 |
| coercivity, healthy | 60.8 A/m (sd 8.0) | 676.7 A/m (sd 51.3) |
| coercivity, irradiated | 66.8 A/m (sd 0.0) | 1558 A/m (sd 131) |
| change in coercivity | +9.8 % | +130.3 % |
| remanence, healthy | 0 T | 0.428 T (sd 0.035) |
| remanence, irradiated | 0 T | 0.703 T (sd 0.044) |
| change in remanence | +0.0 % | +64.2 % |
| change in peak permeability | -25.6 % | -27.4 % |
| change in hysteresis loss | not reported | +125.6 % |
| effect size on coercivity | 1.05 | 8.88 |

Thermal, from `thermal.py`:

| quantity | published | corrected |
|---|---|---|
| derating factor at 290 C | not computed, 0.73 quoted in the table | 0.741 |
| signal-to-noise ratio at 290 C | not stated | 6.73 |
| margin at 290 C | 48.4, called dB | 16.6 dB |
| detection threshold, SNR = 10 | described as 10 | 20 dB |
| temperature at which SNR falls to 10 | text says about 450 C | 160 C |

## Two things the corrected model says that the manuscript does not

The peak permeability drop of 27.4 per cent survives correction and matches what
Section 5 already claims. Nothing else does.

The thermal margin does not meet the paper's own criterion. At 290 C the corrected
margin is 16.6 dB against a 20 dB threshold, a shortfall of 3.4 dB, and the
threshold is crossed at 160 C rather than 450 C. On this noise model the array
does not reach reliable detection at operating temperature. The noise model itself
is in arbitrary units and is not the femtotesla budget quoted in Section 6, so the
honest reading is that the thermal case has not yet been made rather than that it
fails.

## One judgement to make

A coercivity rise of 130 per cent is far above what the irradiation literature
reports, which is tens of per cent. That comes from the pinning multiplier of 2.5,
which was in the notebook as a hard-coded constant and which I preserved rather
than invented. If you anchor it to Kobayashi's measured coercivity shifts, change
`K_RATIO_AT_EOL` in `rpv_model.py` and re-run `run_mc.py`; everything downstream
follows from that one number.
